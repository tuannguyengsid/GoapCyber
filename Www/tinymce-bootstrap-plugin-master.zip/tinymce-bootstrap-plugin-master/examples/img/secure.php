<?php
    exit('Hello !');
