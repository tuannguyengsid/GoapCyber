tinymce.addI18n('en_EN', {
    "Insert/Edit Bootstrap Button": "Insert/Edit Bootstrap Button",
    "Insert/Edit Bootstrap Icon": "Insert/Edit Bootstrap Icon",
    "Insert/Edit Bootstrap Image": "Insert/Edit Bootstrap Image",
    "Insert/Edit Bootstrap Table": "Insert/Edit Bootstrap Table",
    "Insert Bootstrap Template": "Insert Bootstrap Template",
    "Insert/Edit Bootstrap Breadcrumb": "Insert/Edit Bootstrap Breadcrumb",
    "Insert/Edit Bootstrap Pagination": "Insert/Edit Bootstrap Pagination",
    "Insert/Edit Bootstrap Pager": "Insert/Edit Bootstrap Pager",
    "Insert/Edit Bootstrap Label": "Insert/Edit Bootstrap Label",
    "Insert/Edit Bootstrap Badge": "Insert/Edit Bootstrap Badge",
    "Insert/Edit Bootstrap Alert": "Insert/Edit Bootstrap Alert",
    "Insert/Edit Bootstrap Panel": "Insert/Edit Bootstrap Panel",
    "Insert/Edit Snippet": "Insert/Edit Snippet"
});